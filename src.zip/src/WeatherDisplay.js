import React, { useState, useEffect } from 'react';

const WeatherDisplay = () => {
  const [weatherData, setWeatherData] = useState(null);

  useEffect(() => {
    // Aquí puedes realizar una llamada a una API para obtener datos de clima
    // y luego actualizar el estado con setWeatherData.
    // Por simplicidad, dejamos esto como un ejemplo básico.
    const fakeWeatherData = { temperature: 25, condition: 'Soleado' };
    setWeatherData(fakeWeatherData);
  }, []);

  return (
    <div>
      <h2>Visualización del Clima</h2>
      {weatherData ? (
        <p>{`Temperatura: ${weatherData.temperature}°C, Condición: ${weatherData.condition}`}</p>
      ) : (
        <p>Cargando datos de clima...</p>
      )}
    </div>
  );
};

export default WeatherDisplay;
