import React, { useState } from 'react';

const DogAgeCalculator = () => {
  const [humanAge, setHumanAge] = useState(0);
  const [dogAge, setDogAge] = useState(0);

  const handleCalculate = () => {
    // Realiza el cálculo de edad canina según tu fórmula
    const calculatedDogAge = humanAge * 7;
    setDogAge(calculatedDogAge);
  };

  return (
    <div>
      <h2>Cálculo de Edad Canina</h2>
      <label>
        Edad Humana:
        <input type="number" value={humanAge} onChange={(e) => setHumanAge(e.target.value)} />
      </label>
      <button onClick={handleCalculate}>Calcular Edad Canina</button>
      <p>Edad Canina: {dogAge}</p>
    </div>
  );
};

export default DogAgeCalculator;
