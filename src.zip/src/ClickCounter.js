import React, { useState } from 'react';

const ClickCounter = () => {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <h2>Contador de Clicks</h2>
      <p>Clicks: {count}</p>
      <button onClick={handleIncrement}>Incrementar</button>
    </div>
  );
};

export default ClickCounter;
