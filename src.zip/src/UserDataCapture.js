import React, { useState } from 'react';

const UserDataCapture = () => {
  const [userData, setUserData] = useState({ name: '', age: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };

  return (
    <div>
      <h2>Captura de Datos de Usuario</h2>
      <label>
        Nombre:
        <input type="text" name="name" value={userData.name} onChange={handleChange} />
      </label>
      <label>
        Edad:
        <input type="number" name="age" value={userData.age} onChange={handleChange} />
      </label>
      <p>{`Nombre: ${userData.name}, Edad: ${userData.age}`}</p>
    </div>
  );
};

export default UserDataCapture;
