import React, { useState } from 'react';
import ClickCounter from './ClickCounter';
import UserDataCapture from './UserDataCapture';
import DogAgeCalculator from './DogAgeCalculator';
import WeatherDisplay from './WeatherDisplay';

const App = () => {
  const [modulesEnabled, setModulesEnabled] = useState({
    clickCounter: true,
    userDataCapture: true,
    dogAgeCalculator: true,
    weatherDisplay: true,
  });

  const handleToggleModule = (moduleName) => {
    setModulesEnabled((prevModules) => ({
      ...prevModules,
      [moduleName]: !prevModules[moduleName],
    }));
  };

  return (
    <div>
      {modulesEnabled.clickCounter && <ClickCounter />}
      {modulesEnabled.userDataCapture && <UserDataCapture />}
      {modulesEnabled.dogAgeCalculator && <DogAgeCalculator />}
      {modulesEnabled.weatherDisplay && <WeatherDisplay />}
      <div>
        <h2>Configuración de Módulos</h2>
        {Object.keys(modulesEnabled).map((moduleName) => (
          <label key={moduleName}>
            {moduleName}
            <input
              type="checkbox"
              checked={modulesEnabled[moduleName]}
              onChange={() => handleToggleModule(moduleName)}
            />
          </label>
        ))}
      </div>
    </div>
  );
};

export default App;
